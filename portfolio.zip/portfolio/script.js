/* ============================================================
   Sathish R — Portfolio interactions
   1. Mobile navigation menu
   2. Scroll progress bar + solid nav on scroll
   3. Active navigation link highlighting
   4. Scroll-reveal animations
   5. Back-to-top button
   6. Contact form validation
   All code is dependency-free vanilla JavaScript.
   ============================================================ */

"use strict";

// Mark that JS is available — enables hidden-until-revealed styles in CSS.
document.documentElement.classList.add("js");

/* ------------------------------------------------------------
   1. Mobile navigation menu
   ------------------------------------------------------------ */
const navLinks = document.getElementById("nav-links");
const navToggle = document.getElementById("nav-toggle");
const navClose = document.getElementById("nav-close");

function openMenu() {
  navLinks.classList.add("is-open");
  document.body.classList.add("nav-open");
  navToggle.setAttribute("aria-expanded", "true");
  navToggle.setAttribute("aria-label", "Close menu");
  navClose.focus(); // move focus into the menu for keyboard users
}

function closeMenu() {
  navLinks.classList.remove("is-open");
  document.body.classList.remove("nav-open");
  navToggle.setAttribute("aria-expanded", "false");
  navToggle.setAttribute("aria-label", "Open menu");
}

navToggle.addEventListener("click", () => {
  navLinks.classList.contains("is-open") ? closeMenu() : openMenu();
});

navClose.addEventListener("click", closeMenu);

// Close the menu after tapping any link inside it
navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", closeMenu);
});

// Close the menu with the Escape key
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && navLinks.classList.contains("is-open")) {
    closeMenu();
    navToggle.focus();
  }
});

/* ------------------------------------------------------------
   2. Scroll progress bar + solid nav background
   (one scroll listener, throttled with requestAnimationFrame)
   ------------------------------------------------------------ */
const progressBar = document.querySelector(".progress");
const nav = document.getElementById("nav");
const toTop = document.getElementById("to-top");

function handleScroll() {
  const scrollY = window.scrollY;
  const pageHeight = document.documentElement.scrollHeight - window.innerHeight;

  // Fill the top progress bar according to scroll position
  const progress = pageHeight > 0 ? scrollY / pageHeight : 0;
  progressBar.style.transform = `scaleX(${progress})`;

  // Solid nav background once we scroll past the hero a little
  nav.classList.toggle("is-scrolled", scrollY > 40);

  // Show the back-to-top button after scrolling one viewport down
  toTop.classList.toggle("is-visible", scrollY > window.innerHeight * 0.8);
}

let ticking = false;
window.addEventListener("scroll", () => {
  if (!ticking) {
    window.requestAnimationFrame(() => {
      handleScroll();
      ticking = false;
    });
    ticking = true;
  }
});

handleScroll(); // set the correct state on page load

/* ------------------------------------------------------------
   5. Back-to-top button
   (smooth scrolling comes from CSS: html { scroll-behavior: smooth })
   ------------------------------------------------------------ */
toTop.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

/* ------------------------------------------------------------
   3. Active navigation link highlighting
   Uses IntersectionObserver to detect the section in view.
   ------------------------------------------------------------ */
const sections = document.querySelectorAll("section[id]");
const menuLinks = document.querySelectorAll(".nav__link");

const sectionObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const id = entry.target.id;
      menuLinks.forEach((link) => {
        // "Resume ↗" points to a file, not a section — skip it
        const pointsHere = link.getAttribute("href") === `#${id}`;
        link.classList.toggle("is-active", pointsHere);
      });
    });
  },
  { rootMargin: "-45% 0px -50% 0px" } // activates near the middle of the viewport
);

sections.forEach((section) => sectionObserver.observe(section));

/* ------------------------------------------------------------
   4. Scroll-reveal animations
   Elements with class "reveal" fade in the first time they
   enter the viewport.
   ------------------------------------------------------------ */
const revealElements = document.querySelectorAll(".reveal");

// Fallback: if the browser is too old for IntersectionObserver,
// simply show everything instead of leaving it hidden.
if (!("IntersectionObserver" in window)) {
  revealElements.forEach((element) => element.classList.add("is-visible"));
} else {
  const revealObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target); // animate only once
        }
      });
    },
    { threshold: 0.12 } // reveal when ~12% of the element is visible
  );

  revealElements.forEach((element) => revealObserver.observe(element));
}

/* ------------------------------------------------------------
   6. Contact form validation
   NOTE: a static site cannot send email by itself. To deliver
   real messages, sign up for a free form service and put its
   endpoint in the form's action attribute, for example:

   <form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">

   (Formspree, Netlify Forms and Web3Forms all have free tiers.)
   ------------------------------------------------------------ */
const form = document.getElementById("contact-form");
const status = document.getElementById("form-status");

// Small helpers for showing / clearing errors
function setError(field, message) {
  field.setAttribute("aria-invalid", "true");
  document.getElementById(`${field.id}-error`).textContent = message;
}

function clearError(field) {
  field.removeAttribute("aria-invalid");
  document.getElementById(`${field.id}-error`).textContent = "";
}

// Returns an error message for a field, or "" when it is valid
function validateField(field) {
  const value = field.value.trim();

  switch (field.id) {
    case "name":
      if (value === "") return "Please enter your name.";
      if (value.length < 2) return "Name must be at least 2 characters.";
      return "";
    case "email":
      if (value === "") return "Please enter your email address.";
      // Simple, practical email pattern
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) {
        return "Please enter a valid email address.";
      }
      return "";
    case "subject":
      if (value === "") return "Please enter a subject.";
      if (value.length < 3) return "Subject must be at least 3 characters.";
      return "";
    case "message":
      if (value === "") return "Please write a message.";
      if (value.length < 10) return "Message must be at least 10 characters.";
      return "";
    default:
      return "";
  }
}

// Validate individual fields live once the user leaves them
form.querySelectorAll("input, textarea").forEach((field) => {
  field.addEventListener("blur", () => {
    const error = validateField(field);
    error ? setError(field, error) : clearError(field);
  });
  // Clear the error as soon as the user starts fixing it
  field.addEventListener("input", () => {
    if (field.getAttribute("aria-invalid") === "true" && validateField(field) === "") {
      clearError(field);
    }
  });
});

// Validate everything when the form is submitted
form.addEventListener("submit", (event) => {
  event.preventDefault(); // never reload the page

  const fields = form.querySelectorAll("input, textarea");
  let firstInvalid = null;

  fields.forEach((field) => {
    const error = validateField(field);
    if (error) {
      setError(field, error);
      if (!firstInvalid) firstInvalid = field;
    } else {
      clearError(field);
    }
  });

  // Something is wrong → focus the first invalid field
  if (firstInvalid) {
    status.textContent = "Please fix the highlighted fields and try again.";
    status.classList.add("is-error");
    firstInvalid.focus();
    return;
  }

  // Everything is valid.
  // This demo has no backend, so we confirm locally and offer a mailto fallback.
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const subject = document.getElementById("subject").value.trim();
  const message = document.getElementById("message").value.trim();

  // Tiny helper so user text is inserted safely
  const escapeHtml = (text) =>
    text.replace(/[&<>"']/g, (char) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char])
    );

  status.classList.remove("is-error");
  status.innerHTML =
    `Thanks, ${escapeHtml(name)}! Your message is valid and ready to send. ` +
    `This static form cannot deliver email on its own — connect a free service ` +
    `(like Formspree) or email me directly at ` +
    `<a href="mailto:sathishr0165@gmail.com?subject=` +
    encodeURIComponent(subject) +
    `&body=` +
    encodeURIComponent(`${message}\n\n— ${name} (${email})`) +
    `" style="color:var(--accent);text-decoration:underline;">sathishr0165@gmail.com</a>.`;

  form.reset(); // clear the inputs
});
